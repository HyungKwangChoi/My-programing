from PyQt5.QtWidgets import QWidget, QLineEdit
from PyQt5.QtWidgets import QTreeWidget
from PyQt5.QtWidgets import QSpinBox
from PyQt5.QtCore import QVariant
from PyQt5.QtWidgets import QTreeWidgetItem
from PyQt5.QtWidgets import QApplication
from PyQt5.QtWidgets import QBoxLayout
from PyQt5.QtCore import Qt


class Form(QWidget):
    def __init__(self):
        QWidget.__init__(self, flags=Qt.Widget)
        self.setWindowTitle("QTreeWidget Column")
        box = QBoxLayout(QBoxLayout.TopToBottom)
        self.setLayout(box)
        # QTreeView 생성 및 설정
        self.tw = QTreeWidget(self)
        box.addWidget(self.tw)
        self.tw.setColumnCount(4)
        self.tw.setHeaderLabels(["File Name", "OID", "Label", "Color"])
        root_1 = QTreeWidgetItem(self.tw)
        root_1.setText(0, "File Name")
        root_1.setText(1, "what")
        # root_1.setText(1, "Option_1 Description")
        root_1.setFlags(root_1.flags() | Qt.ItemIsEditable)
        child_1 = QTreeWidgetItem(root_1)
        child_1.setText(1, "1")
        child_1.setText(2, "2")
        child_1.setText(3, "3")
        child_1.setFlags(root_1.flags() | Qt.ItemIsEditable)


if __name__ == "__main__":
    import sys
    app = QApplication(sys.argv)
    form = Form()
    form.show()
    exit(app.exec_())
