import pandas as pd 

test_dict = {"numbering": ['872', '873','874', '875'], "Time": ['2020-08-13 19:08:13', '2020-08-13 19:08:14',
'2020-08-13 19:08:15', '2020-08-13 19:08:16'], "OID_number": ['7', '8','9','10']}

df = pd.DataFrame(test_dict)
print(df)
#pandas just doesn't work well with custom date-time formats, <class 'pandas.core.indexes.datetimes.DatetimeIndex'>
df['Time'] = pd.to_datetime(df['Time'], format='%Y-%m-%d %H:%M:%S', errors='raise') 
df.drop('numbering',axis=1, inplace=True) #"axis=1, inplace=True" means, please refer to previous explanation. 
df.set_index('Time', inplace=True)
print(df)