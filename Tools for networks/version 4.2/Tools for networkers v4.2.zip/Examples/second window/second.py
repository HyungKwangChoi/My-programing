from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow
 
from PyQt5 import QtWidgets, QtCore, uic
import os
import sys



class SecondForm(QMainWindow):

    def __init__(self, parent=None):
        super(SecondForm, self).__init__()
        
        self.root = os.path.dirname(os.path.realpath(__file__))
        self.ui = uic.loadUi(os.path.join(self.root, 'second_window.ui'), self) 

        self.pushButton2_1.clicked.connect(self.openOtherForm)

    def openOtherForm(self):
        self.a = str(self.lineEdit1.text())


