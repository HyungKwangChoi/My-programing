

import io
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates


data = """
year,data1,data2
2020-10-01,10,100
2020-10-02,20,200
2020-10-03,30,300
2020-10-04,40,400
2020-10-05,50,500
2020-10-06,60,600
2020-10-07,70,700
"""
df = pd.read_csv(io.StringIO(data))
print(df)

df = pd.read_csv(io.StringIO(data),index_col=0)
print(df)
df.index = pd.to_datetime(df.index)


plt.gca().xaxis.set_major_formatter(mdates.DateFormatter('%m/%d'))
line1, = plt.plot(df.index, df['data1'], color='b')
line2, = plt.plot(df.index, df['data2'], color='g')
line1.set_label('data1')
line2.set_label('data2')
 
plt.legend(bbox_to_anchor=(-0.01,-0.01))
plt.title('test')
plt.ylabel("y axis")
plt.xlabel("x axis")
plt.show()
