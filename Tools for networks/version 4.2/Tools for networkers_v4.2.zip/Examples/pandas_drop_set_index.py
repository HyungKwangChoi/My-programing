import pandas as pd 
 

test_dict = {"one": ['1', '2','3', '4'], "two": ['5', '6','7', '8'], "three": ['9', '10','11','12']}
df = pd.DataFrame(test_dict)
print(df)

df.drop('two',axis=1 )
print(df)

df.drop('two',axis=1, inplace=True)
print(df)

df.drop(2,axis=0, inplace=True)
print(df)

df.set_index('three', inplace=True)
print(df)