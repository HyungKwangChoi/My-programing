import pandas as pd 

test1_dict = { "Time": ['2020-08-13 19:08:13', '2020-08-13 19:08:14',
'2020-08-13 19:08:15', '2020-08-13 19:08:16'], "OID": ['7', '7','7','7']}

test2_dict = { "Time": ['2020-08-13 19:08:15', '2020-08-13 19:08:16',
'2020-08-13 19:08:17', '2020-08-13 19:08:18'], "OID": ['10', '10','10','10']}


df1 = pd.DataFrame(test1_dict)
print(df1)

df2 = pd.DataFrame(test2_dict)
print(df2)

df = pd.merge(df1, df2, how='outer', on='Time') # 'outer' mean full merge. 
print(df)