from PyQt5.QtWidgets import QApplication, QWidget, QMainWindow
 
from PyQt5 import QtWidgets, QtCore, uic

import os
import sys
from second import SecondForm

class FirstForm(QMainWindow):

    def __init__(self):
        super(FirstForm, self).__init__()

        self.root = os.path.dirname(os.path.realpath(__file__))
        self.ui = uic.loadUi(os.path.join(self.root, 'master_window.ui'), self) #If hes
     #   self.ui.show()

        self.pushButton1_1.clicked.connect(self.openOtherForm)
        self.otherview = SecondForm()


    def openOtherForm(self):
        #self.hide()

        self.otherview.show()
  
        print("test")
    

    def slot1(self):

        self.textBrowser1.append(self.otherview.a)



app = QApplication(sys.argv)
main = FirstForm()
main.show()
sys.exit(app.exec_())