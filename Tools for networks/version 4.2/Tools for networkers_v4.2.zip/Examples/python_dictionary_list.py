car = {
  "brand": "Ford",
  "model": "Mustang",
   "year": 1964
}

x = car.setdefault("color",  "white")

print(x) 

dict1 = {}

x = 0
for i in range(5) :
    x = x + i
    dict1[i] = [x, x, x]

print(dict1)
