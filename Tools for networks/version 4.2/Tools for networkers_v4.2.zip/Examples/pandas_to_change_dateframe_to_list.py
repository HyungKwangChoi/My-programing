import pandas as pd 

df = pd.DataFrame({"one":[1,4,7], "two":[2,5,8], "three":[3,6,9]})

print(df)

print(df['two']) 

a = list(df['two'].tolist())
print(a)

x = df.iloc[:,1]
x = list(x.tolist())

print(x)