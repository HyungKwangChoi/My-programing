from os.path import basename
filename = 'C:\\temp\\test\\text.txt'
print(basename(filename))
 