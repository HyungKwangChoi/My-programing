import pandas as pd 

test_dict = { "Time": ['2020-08-13 19:08:13', '2020-08-13 19:08:14',
'2020-08-13 19:08:15', '2020-08-13 19:08:16'], "OID": ['7', '7','7','7']}

df = pd.DataFrame(test_dict)

# Extracting header info
print(df.columns)
print(list(df.columns))