import pandas as pd 
import numpy as np
import io

######## DataFrame Creation example ############

test_2D_array = np.array([[1, 2, 3], [4, 5, 6]])
df = pd.DataFrame(test_2D_array)
print(df)
df = pd.DataFrame(np.arange(16).reshape(4,4), index=['test1', 'test2','test3','test4'], columns=['one','two','three','four'])
print(df)
df = pd.DataFrame(np.arange(16).reshape(4,4), index=range(0,4), columns=['one','two','three','four'])
print(df)
test_dict = {"one": ['1', '2','3', '4'], "two": ['5', '6','7', '8'], "three": ['9', '10','11','12']}
df = pd.DataFrame(test_dict)
print(df)


data = """
year,data1,data2
2020-10-01,10,100
2020-10-02,20,200
2020-10-03,30,300
2020-10-04,40,400
2020-10-05,50,500
2020-10-06,60,600
2020-10-07,70,700
"""
df = pd.read_csv(io.StringIO(data))
print(df)

df = pd.read_csv(io.StringIO(data),index_col=0)
df.index = pd.to_datetime(df.index)
print(df)


######## Series Creation example ###############
df = pd.Series({"one":"aa", "two":"bb", "three":"cc", "four":"dd"})
print(df)

####### Test ###################################

df = pd.DataFrame({"one":[1,4,7], "two":[2,5,8], "three":[3,6,9]})

print(df)

#  `iloc[]` used for a row
print(df.iloc[0])
print(df.loc[0]) 

#  `loc[]` used for a column
print(df.loc[:,'one'])
print(df['one'])

# specific row & column
print(df.loc[0]['two']) #please figure out how it differs
#print(df.loc[-1]['B'])  #<===== This return's an error

# "-1" mean last .
print(df.iloc[[0],[1]])
print(df.iloc[[-1],[1]])

print(df.iloc[0],['three'])
print(df.iloc[-1],['three'])

print(df.iloc[:,1])
print(df.iloc[:,1:2])
print(df.iloc[:,[0,2]])

print(df.iloc[[0,-1],:])
